@extends('frontend.layouts.app'.config('theme_layout'))
@section('title', trans('labels.frontend.home.title').' | '.app_name())
@push('after-styles')
<style>
       
        .teacher-img-content .teacher-social-name{
            max-width: 67px;
        }
        .my-alert{
            position: absolute;
            z-index: 10;
            left: 0;
            right: 0;
            top: 25%;
            width: 50%;
            margin: auto;
            display: inline-block; 
        } 
    #ticker01{
      overflow: hidden;
    }
    </style>
@endpush

@section('content')
<section class="slider-area zIn-9999 bgGray">
  <div class="homepage-slide1">
  
      <div class="w-100">
      <div class="closeBox"><a href="{{url('/')}}">x</a></div>
        <div class="BeneficiariesBox">
      <h2>Analytics</h2>
      
       <!--graph section-->
  <div class="container-fluid pb-5">

    <div class="row">
      <div class="col-sm-12 col-lg-6">
        <div class="card">
          <div class="card-tittle" id="schoolCollagePanel"> Classroom Training 
        <span>
          <span class="chartIcon"><img src="{{asset('assets/images/icon/line.svg')}}" id="lineChartBtn"></span> 
          <span class="chartIcon"><img src="{{asset('assets/images/icon/bar-chart.svg')}}" id="barChartBtn"></span> 
          <span class="chartIcon"><img src="{{asset('assets/images/icon/filter.svg')}}" class="filterBtn-1"></span>
        </span>
          </div>
          <!--filter Box-->
          <div class="filterPanel f-box-1" style="display:none;">
            <div class="row">
              <div class="col-md-4">
                <p>Name of insecticide</p>
                <select class="form-control">
                  <option value="#">2,4-Dichlorophenoxy Acetic Acid</option>
                  <option value="#">Alachlor</option>
                  <option value="#">Alpha cypermethrin</option>
                  <option value="#">Benfuracarb</option>
                  <option value="#">Beta Cyfluthrin</option>
                </select>
              </div>
              
              <!--/01-->
              <div class="col" style="padding-top:20px;">
                <button type="submit" class="btn  btn-success">Go</button>
                <a href="#" class="btn btn-info">Reset</a> </div>
              <!--/01--> 
            </div>
          </div>
          <!--filter Box-->
          
          <div class="card-body">
            <div class="chartjs-size-monitor">
              <div class="chartjs-size-monitor-expand">
                <div class=""></div>
              </div>
              <div class="chartjs-size-monitor-shrink">
                <div class=""></div>
              </div>
            </div>
            <canvas id="webinarsChart" class="chartjs-render-monitor" width="479" height="255" style="display: block; width: 479px; height: 255px;"></canvas>
          </div>
        </div>
      </div>
      
      <!---graph 2-->
      <div class="col-sm-12 col-lg-6">
        <div class="card">
          <div class="card-tittle" id="constituencyPanel"> Trending E-Learning Courses<span> <span class="chartIcon"><img src="{{asset('assets/images/icon/line.svg')}}" id="lineChartBtn"></span> <span class="chartIcon"><img src="{{asset('assets/images/icon/bar-chart.svg')}}" id="barChartBtn"></span> <span class="chartIcon"><img src="{{asset('assets/images/icon/filter.svg')}}" class="filterBtn-2"> </span> </span></div>
          <!--filter Box-->
          <div class="filterPanel f-box-2" style="display:none;">
            <div class="row">
              <div class="col-md-4">
                <p>Name of Antibiotics </p>
                <select class="form-control">
                  <option value="#">Tetracycline</option>
                  <option value="#">Oxytetracycline</option>
                  <option value="#">Trimethoprim</option>
                  <option value="#">Oxolinic Self Assessment </option>
                </select>
              </div>
              
              <!--/01-->
              <div class="col" style="padding-top:20px;">
                <button type="submit" class="btn  btn-success">Go</button>
                <a href="#" class="btn btn-info">Reset</a> </div>
              <!--/01--> 
            </div>
          </div>
          <!--filter Box-->
          
          <div class="card-body">
            <div class="chartjs-size-monitor">
              <div class="chartjs-size-monitor-expand">
                <div class=""></div>
              </div>
              <div class="chartjs-size-monitor-shrink">
                <div class=""></div>
              </div>
            </div>
            <canvas id="constituencyDetailsChart" class="chartjs-render-monitor" width="479" height="255" style="display: block; width: 479px; height: 255px;"></canvas>
          </div>
        </div>
      </div>
    </div>
    
    
    <div class="row">
      <div class="col-sm-12 col-lg-6">
        <div class="card">
          <div class="card-tittle" id="schoolCollagePanel"> Webinar 
        <span>
          <span class="chartIcon"><img src="{{asset('assets/images/icon/line.svg')}}" id="lineChartBtn"></span> 
          <span class="chartIcon"><img src="{{asset('assets/images/icon/bar-chart.svg')}}" id="barChartBtn"></span> 
          <span class="chartIcon"><img src="{{asset('assets/images/icon/filter.svg')}}" class="filterBtn-1"></span>
        </span>
          </div>
          <!--filter Box-->
          <div class="filterPanel f-box-1" style="display:none;">
            <div class="row">
              <div class="col-md-4">
                <p>Name of insecticide</p>
                <select class="form-control">
                  <option value="#">2,4-Dichlorophenoxy Acetic Acid</option>
                  <option value="#">Alachlor</option>
                  <option value="#">Alpha cypermethrin</option>
                  <option value="#">Benfuracarb</option>
                  <option value="#">Beta Cyfluthrin</option>
                </select>
              </div>
              
              <!--/01-->
              <div class="col" style="padding-top:20px;">
                <button type="submit" class="btn  btn-success">Go</button>
                <a href="#" class="btn btn-info">Reset</a> </div>
              <!--/01--> 
            </div>
          </div>
          <!--filter Box-->
          
          <div class="card-body">
            <div class="chartjs-size-monitor">
              <div class="chartjs-size-monitor-expand">
                <div class=""></div>
              </div>
              <div class="chartjs-size-monitor-shrink">
                <div class=""></div>
              </div>
            </div>
            <canvas id="WebinarChartStBox" class="chartjs-render-monitor" width="479" height="255" style="display: block; width: 479px; height: 255px;"></canvas>
          </div>
        </div>
      </div>
      
      <!---graph 2-->
      <div class="col-sm-12 col-lg-6">
        <div class="card">
          <div class="card-tittle" id="constituencyPanel"> Seminar and Workshops<span> <span class="chartIcon"><img src="{{asset('assets/images/icon/line.svg')}}" id="lineChartBtn"></span> <span class="chartIcon"><img src="{{asset('assets/images/icon/bar-chart.svg')}}" id="barChartBtn"></span> <span class="chartIcon"><img src="{{asset('assets/images/icon/filter.svg')}}" class="filterBtn-2"> </span> </span></div>
          <!--filter Box-->
          <div class="filterPanel f-box-2" style="display:none;">
            <div class="row">
              <div class="col-md-4">
                <p>Name of Antibiotics </p>
                <select class="form-control">
                  <option value="#">Tetracycline</option>
                  <option value="#">Oxytetracycline</option>
                  <option value="#">Trimethoprim</option>
                  <option value="#">Oxolinic Self Assessment </option>
                </select>
              </div>
              
              <!--/01-->
              <div class="col" style="padding-top:20px;">
                <button type="submit" class="btn  btn-success">Go</button>
                <a href="#" class="btn btn-info">Reset</a> </div>
              <!--/01--> 
            </div>
          </div>
          <!--filter Box-->
          
          <div class="card-body">
            <div class="chartjs-size-monitor">
              <div class="chartjs-size-monitor-expand">
                <div class=""></div>
              </div>
              <div class="chartjs-size-monitor-shrink">
                <div class=""></div>
              </div>
            </div>
            <canvas id="SeminarWorkshopsChart" class="chartjs-render-monitor" width="479" height="255" style="display: block; width: 479px; height: 255px;"></canvas>
          </div>
        </div>
      </div>
    </div>
    
    
   
  </div>
  <!--graph section emds--> 
       
       
       </div>
     
     
     
     
     
     
      </div>
 
  </div>
</section>
@endsection

<script type="text/javascript">
$(document).ready(function(){

  var dd = $('.ticker01').easyTicker({
    direction: 'up',
    easing: 'easeInOutBack',
    speed: 'slow',
    interval: 2000,
    height: 'auto',
    visible: 10,
    mousePause: 0,
    controls: {
      up: '.up',
      down: '.down',
      toggle: '.toggle',
      stopText: 'Stop !!!'
    }
  }).data('easyTicker');
  
  cc = 1;
  $('.aa').click(function(){
    $('.ticker01 ul').append('<li>' + cc + ' Triangles can be made easily using CSS also without any images. This trick requires only div tags and some</li>');
    cc++;
  });
  
  $('.vis').click(function(){
    dd.options['ticker01'] = 3;
    
  });
  
  $('.ticker01').click(function(){
    dd.stop();
    dd.options['ticker01'] = 0 ;
    dd.start();
  });
  
});
</script>

<script>
$(function() {
  $('[data-toggle="popover"]').each(function(i, obj) {
    var popover_target = $(this).data('popover-target');
  
    $(this).popover({
        html: true,
        trigger: 'manual',
    delay: { 
             show:0, 
             hide: 0
    },
        placement: 'right',
        content: function(obj) {
            return $('#trendingCoursesHoverArea').html();
        }
    }).on("mouseenter", function () {
        var _this = this;
        var dynamic_elementid = $(this).attr('data-element');
        var allelements = $("#"+dynamic_elementid).html();
        var name = allelements.split('##**##')[0];
        var title = allelements.split('##**##')[1];
        var description = allelements.split('##**##')[2];
        var route = allelements.split('##**##')[3];
        $("#popover_name").html(name);
        $("#popover_title").html(title);
        $("#popover_description").html(description);
        $("#popover_redirection").attr('href',route);
        $(this).popover("show");
        $(".popover").on("mouseleave", function () {
            $("#popover_name").html();
            $("#popover_title").html();
            $("#popover_description").html();
            $("#popover_route").html();
            $(_this).popover('hide');
        });
    }).on("mouseleave", function () {
        var _this = this;
        setTimeout(function () {
            if (!$(".popover:hover").length) {
                $(_this).popover("hide");
            }
        }, 300);
});
  });
});
</script>
<script>
var classroom_headings = <?php echo $chart_category_names ?>;
var classroom_chartdata = <?php echo $chart_category_data_count ?>;
var trending_headings = <?php echo $trending_courses ?>;
var trending_chartdata = <?php echo $trending_courses_data ?>;
$(document).ready(function() {
$(".headerTextSlider").click(function () {
    $(".headerTextSlider").removeClass("active");
    // $(".tab").addClass("active"); // instead of this do the below 
    $(this).addClass("active");   
});
$(".findbox").click(function () {
    $(".findbox").removeClass("active");
    // $(".tab").addClass("active"); // instead of this do the below 
    $(this).addClass("active");   
});
});

</script>