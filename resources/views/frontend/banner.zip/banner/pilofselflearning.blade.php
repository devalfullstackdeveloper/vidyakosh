@extends('frontend.layouts.app'.config('theme_layout'))
@section('title', trans('labels.frontend.home.title').' | '.app_name())
@section('meta_description', '')
@section('meta_keywords','')


@push('after-styles')
<style>
        /*.address-details.ul-li-block{*/
        /*line-height: 60px;*/
        /*}*/
        .teacher-img-content .teacher-social-name{
            max-width: 67px;
        }
        .my-alert{
            position: absolute;
            z-index: 10;
            left: 0;
            right: 0;
            top: 25%;
            width: 50%;
            margin: auto;
            display: inline-block; 
        } 
    #ticker01{
      overflow: hidden;
    }
    </style>
@endpush

@section('content')
<section class="slider-area mb-5 zIn-9999">
  <div class="homepage-slide1">
    <div class="single-slide-item slide-bg1">
      <div class="container">
      <div class="closeBox"><a href="{{url('/')}}">x</a></div>
       
      <div class="pillarsOfLearning">
      <h2>Four pillars of  E-Learning Methodology</h2>
      
      <div class="row">
      <!--box01-->
      <div class="col-12 col-md-6 col-lg-3">
      
      <div class="pillarsOfLearningBox learningBox-1 up">
      <i class="vM"><img src="{{asset('assets/images/elearning.svg')}}"></i>
      <h5>E-Learning</h5>
      <span class="vM">{{$coursescount}}</span>
      </div>
      </div>
       <!--./box01-->
        <!--box01-->
      <div class="col-12 col-md-6 col-lg-3">
      
      <div class="pillarsOfLearningBox learningBox-2 up">
      <i class="vM"><img src="{{asset('assets/images/crt.svg')}}"></i>
      <h5>CRT</h5>
      <span class="vM">{{$crtcount}}</span>
      </div>
      </div>
       <!--./box01-->
        <!--box01-->
      <div class="col-12 col-md-6 col-lg-3">
      
      <div class="pillarsOfLearningBox learningBox-3 up">
      <i class="vM"><img src="{{asset('assets/images/webinar.svg')}}"></i>
      <h5>Webinar</h5>
      <span class="vM">03</span>
      </div>
      </div>
       <!--./box01-->
        <!--box01-->
      <div class="col-12 col-md-6 col-lg-3">
      
      <div class="pillarsOfLearningBox learningBox-4 up">
      <i class="vM"><img src="{{asset('assets/images/seminar.svg')}}"></i>
      <h5>Seminar &
workshop</h5>
      <span class="vM">04</span>
      </div>
      </div>
       <!--./box01-->
      
      </div>
      </div>
      </div>
    </div>
  </div>
</section>
@endsection