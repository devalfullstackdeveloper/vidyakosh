@extends('frontend.layouts.app'.config('theme_layout'))
@section('title', trans('labels.frontend.home.title').' | '.app_name())
@section('meta_description', '')
@section('meta_keywords','')


@push('after-styles')
    <style>
        /*.address-details.ul-li-block{*/
        /*line-height: 60px;*/
        /*}*/
        .teacher-img-content .teacher-social-name{
            max-width: 67px;
        }
        .my-alert{
            position: absolute;
            z-index: 10;
            left: 0;
            right: 0;
            top: 25%;
            width: 50%;
            margin: auto;
            display: inline-block; 
        } 
    #ticker01{
      overflow: hidden;
    }
    </style>
@endpush

@section('content')



<section class="slider-area zIn-9999 bgGray">
  <div class="homepage-slide1">
  
      <div class="container">
      <div class="closeBox"><a href="{{url('/')}}">x</a></div>
        <div class="BeneficiariesBox">
      <h2>Beneficiaries</h2>
      
      
      
      <div class="row">
      <div class="col-sm-12">
        <div class="card">
          <div class="card-tittle" id="schoolCollagePanel"> Growth Path 
       <!-- <span>
          <span class="chartIcon"><img src="{{asset('assets/images/icon/line.svg')}}" id="lineChartBtn"></span> 
          <span class="chartIcon"><img src="{{asset('assets/images/icon/bar-chart.svg')}}" id="barChartBtn"></span> 
          <span class="chartIcon"><img src="{{asset('assets/images/icon/filter.svg')}}" class="filterBtn-1"></span>
        </span>-->
          </div>
         
          <div class="card-body">
            <div class="chartjs-size-monitor">
              <div class="chartjs-size-monitor-expand">
                <div class=""></div>
              </div>
              <div class="chartjs-size-monitor-shrink">
                <div class=""></div>
              </div>
            </div>
          
            <canvas id="beneficiariesChart" class="chartjs-render-monitor" width="479" height="455" style="display: block; width: 479px; height: 455px;"></canvas>
            
            
            
          </div>
          
          <div class="text-center mb-4">Beneficiaries / Type of Training</div>
        </div>
      </div>
      
      
    </div>
      
      
      
      
      
      
      
      
      
       
       </div>
     
     
     
     
     
     
      </div>
 
  </div>
</section>

@endsection

