@extends('backend.layouts.app')
@section('title', __('labels.backend.designations.title').' | '.app_name())

@section('content')
    {{ html()->modelForm($designations, 'PATCH', route('admin.designations.update', $designations->id))->class('form-horizontal')->acceptsFiles()->open() }}

    <div class="card">
        <div class="card-header">
            <h3 class="page-title d-inline">@lang('labels.backend.designations.edit')</h3>
            <div class="float-right">
                <a href="{{ route('admin.designations.index') }}"
                   class="btn btn-success">@lang('labels.backend.designations.view')</a>
            </div>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-12">
                    <div class="form-group row">
                        {{ html()->label(__('labels.backend.designations.fields.designation'))->class('col-md-2 form-control-label')->for('designation') }}

                        <div class="col-md-10">
                            {{ html()->text('designation')
                                ->class('form-control')
                                ->placeholder(__('labels.backend.designations.fields.designation'))
                                ->attribute('maxlength', 100)
                                ->required()
                                ->autofocus() }}
                        </div><!--col-->
                    </div><!--form-group-->

  
                    <div class="form-group row justify-content-center">
                        <div class="col-4">
                            {{ form_cancel(route('admin.cities.index'), __('buttons.general.cancel')) }}
                            {{ form_submit(__('buttons.general.crud.update')) }}
                        </div>
                    </div><!--col-->
                </div>
            </div>
        </div>

    </div>
    {{ html()->closeModelForm() }}
@endsection
