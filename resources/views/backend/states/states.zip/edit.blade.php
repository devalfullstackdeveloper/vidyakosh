@extends('backend.layouts.app')
@section('title', __('labels.backend.states.title').' | '.app_name())

@section('content')
    {{ html()->modelForm($states, 'PATCH', route('admin.states.update', $states->id))->class('form-horizontal')->acceptsFiles()->open() }}

    <div class="card">
        <div class="card-header">
            <h3 class="page-title d-inline">@lang('labels.backend.states.edit')</h3>
            <div class="float-right">
                <a href="{{ route('admin.states.index') }}"
                   class="btn btn-success">@lang('labels.backend.states.view')</a>
            </div>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-12">
                    <div class="form-group row">
                        {{ html()->label(__('labels.backend.states.fields.state'))->class('col-md-2 form-control-label')->for('state') }}

                        <div class="col-md-10">
                            {{ html()->text('state')
                                ->class('form-control')
                                ->placeholder(__('labels.backend.states.fields.state'))
                                ->attribute('maxlength', 100)
                                ->required()
                                ->autofocus() }}
                        </div><!--col-->
                    </div><!--form-group-->

  
                    <div class="form-group row justify-content-center">
                        <div class="col-4">
                            {{ form_cancel(route('admin.states.index'), __('buttons.general.cancel')) }}
                            {{ form_submit(__('buttons.general.crud.update')) }}
                        </div>
                    </div><!--col-->
                </div>
            </div>
        </div>

    </div>
    {{ html()->closeModelForm() }}
@endsection
