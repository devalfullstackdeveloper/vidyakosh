<!DOCTYPE html>
@if(config('app.display_type') == 'rtl' || (session()->has('display_type') && session('display_type') == 'rtl'))
    <html lang="{{ str_replace('_', '-', app()->getLocale()) }}" dir="rtl">

    @else
        <html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

        @endif
        {{--<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" dir="rtl">--}}
        {{--@else--}}
        {{--<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">--}}
        {{--@endlangrtl--}}
        <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
            <meta name="csrf-token" content="{{ csrf_token() }}">
            <title>@yield('title', app_name())</title>
            <meta name="description" content="@yield('meta_description', 'Laravel 5 Boilerplate')">
            <meta name="author" content="@yield('meta_author', 'Anthony Rappa')">
            @if(config('favicon_image') != "")
                <link rel="shortcut icon" type="image/x-icon"
                      href="{{asset('storage/logos/'.config('favicon_image'))}}"/>
            @endif
            @yield('meta')
            <link rel="stylesheet" href="{{asset('css/select2.min.css')}}">
			<link rel="stylesheet" href="{{asset('assets/css/fontawesome-all.css')}}">
            <link rel="stylesheet" href="{{asset('assets/dashboard/css/style.css')}}">
		   <link rel="stylesheet" href="{{asset('assets/css/bootstrap-datepicker.css')}}">
			<link rel="stylesheet" href="{{asset('assets/css/bootstrap.min.css')}}">
			
			<script src="{{asset('assets/js/bootstrap.min.js')}}"></script>
			<script src="{{asset('assets/js/plugin.js')}}"></script>
			<!--script src="{{asset('assets/js/bootstrap-datepicker.js')}}"></script-->
      <script src="{{asset('assets/js/Chart.min.js')}}"></script>
      <script src="{{asset('assets/js/chart.js')}}"></script>
      <!-- <script >
        //scroll bar script
$(document).ready(function(){
  $('.slimscrollPanel').slimScroll({
    height: '195px'
});
$('.slimscrollPanel-0').slimScroll({
    height: '210px'
});

$('.slimscrollPanel-1').slimScroll({
    height: '235px'
});

$('.slimscrollPanel-2').slimScroll({
    height: '245px'
});

$('.slimscrollPanel-4').slimScroll({
    height: '320px'
});


});

      </script> 
 -->
            <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">

            <link rel="stylesheet"
                  href="//cdn.datatables.net/1.10.9/css/jquery.dataTables.min.css"/>
            <link rel="stylesheet"
                  href="https://cdn.datatables.net/select/1.2.0/css/select.dataTables.min.css"/>
            <link rel="stylesheet"
                  href="//cdn.datatables.net/buttons/1.2.4/css/buttons.dataTables.min.css"/>
            {{--<link rel="stylesheet"--}}
            {{--href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/css/bootstrap-datepicker.standalone.min.css"/>--}}
            {{-- See https://laravel.com/docs/5.5/blade#stacks for usage --}}
            <link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">


            @stack('before-styles')

        <!-- Check if the language is set to RTL, so apply the RTL layouts -->
            <!-- Otherwise apply the normal LTR layouts -->
            {{ style(mix('css/backend.css')) }}


            @stack('after-styles')

            @if((config('app.display_type') == 'rtl') || (session('display_type') == 'rtl'))
                <style>
                    .float-left {
                        float: right !important;
                    }

                    .float-right {
                        float: left !important;
                    }
                </style>
            @endif

        </head>

        <body class="{{ config('backend.body_classes') }}">
        @include('backend.includes.header')

        <div class="app-body">
            @include('backend.includes.sidebar')

            <main class="main">
                @include('includes.partials.logged-in-as')
                {{--{!! Breadcrumbs::render() !!}--}}

                <div class="container-fluid" style="padding-top: 30px">
                    <div class="animated fadeIn">
                        <div class="content-header">
                            @yield('page-header')
                        </div><!--content-header-->

                        @include('includes.partials.messages')
                        @yield('content')
                    </div><!--animated-->
                </div><!--container-fluid-->
            </main><!--main-->

            @include('backend.includes.aside')
        </div><!--app-body-->

        @include('backend.includes.footer')

        <!-- Scripts -->
        @stack('before-scripts')
        {!! script(mix('js/manifest.js')) !!}
        {!! script(mix('js/vendor.js')) !!}
        {!! script(mix('js/backend.js')) !!}
        <script>
            //Route for message notification
            var messageNotificationRoute = '{{route('admin.messages.unread')}}'
        </script>
        <script src="//cdn.datatables.net/1.10.9/js/jquery.dataTables.min.js"></script>
        <script src="//cdn.datatables.net/buttons/1.2.4/js/dataTables.buttons.min.js"></script>
        <script src="//cdn.datatables.net/buttons/1.2.4/js/buttons.flash.min.js"></script>
        <script src="//cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js"></script>
        <script src="{{asset('js/pdfmake.min.js')}}"></script>
        <script src="{{asset('js/vfs_fonts.js')}}"></script>
        <script src="https://cdn.datatables.net/buttons/1.2.4/js/buttons.html5.min.js"></script>
        <script src="https://cdn.datatables.net/buttons/1.2.4/js/buttons.print.min.js"></script>
        <script src="https://cdn.datatables.net/buttons/1.2.4/js/buttons.colVis.min.js"></script>
        <script src="https://cdn.datatables.net/select/1.2.0/js/dataTables.select.min.js"></script>
        <script src="https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js"></script>
        <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
	    	<script type="text/javascript" src="{{asset('assets/dashboard/js/chart.min.js')}}"></script>
        <script type="text/javascript" src="{{asset('assets/dashboard/js/script.js')}}"></script>
        <!--script type="text/javascript" src="{{asset('assets/dashboard/js/bootstrap-datepicker.js')}}"></script-->
        <script type="text/javascript" src="{{asset('assets/dashboard/js/chart.js')}}"></script>

        <script src="{{asset('js/select2.full.min.js')}}" type="text/javascript"></script>
       
        <script src="{{asset('js/main.js')}}" type="text/javascript"></script>


     
        <script>
            window._token = '{{ csrf_token() }}';
        </script>

        @stack('after-scripts')

        </body>
		<?php
		if(!empty($courses_list)){?>
		<script type="text/javascript">
            $(document).ready(function(){
  var config = {
    type: 'bar',
    data: {
      labels: @json($courses_list ),
     // labels: ["AI/ML", "Python", "Data Analytics", "DB Systems", "Cyber/App Security", "Sys Adm", "Int & N/W Tech", "Soft Dev"],
      datasets: [{
        label: "Population", 
         data: @json($course_student_count ),
       
        fill: true,
        borderColor: "rgba(49,172,170,0.9)",
        backgroundColor:[ "#36a2eb","#ff6384","#ff9f40","#ffcd56","#4bc0c0","#aedb7c","#9666ba","#fd9677","#aedb7c","#9666ba","#fd9677","#aedb7c","#9666ba","#fd9677","#aedb7c","#9666ba","#fd9677","#ff6384"],
       
   fill: false,
      pointRadius: 4,
     pointHitRadius: 10,
    
      },
    {
          type: 'line', 
          label: 'B',
          // the 1st and last value are placeholders and never get displayed on the chart
          // to get a straight line, the 1st and last values must match the same value as
          // the next/prev respectively
          data: @json($course_student_count ),
          fill: false,
          borderWidth: 3,
          borderColor: "rgba(49,172,170,0.9)",
         backgroundColor:[ "#36a2eb","#ff6384","#ff9f40","#ffcd56","#4bc0c0","#aedb7c","#9666ba","#fd9677","#aedb7c","#9666ba","#fd9677","#aedb7c","#9666ba","#fd9677","#aedb7c","#9666ba","#fd9677","#ff6384"],
          borderDash: [5,4],
          lineTension: 0,
          //steppedLine: true
        }
    
    ]
    },
    
    options: {
      responsive: true,
    legend: {
         display: false,
              position: 'bottom',
          },
        
      scales: {
      yAxes: [{
      ticks: {
         beginAtZero: false
        },
        scaleLabel: {
            labelString: 'No of Trainees',
            display: true,
          },
      }]
    },
    
    title: {
      fontSize: 12,
      display: true,
      text: 'Course',
      position: 'bottom'
    }
    },
    
  };
  var myChart;
   change('bar');
  $("#populationPanel #barChartBtn").click(function() {
    change('bar');
  });
  $("#populationPanel #pieChartBtn").click(function() {
    change('scatter');
    
    //backgroundColor:[ "#ff4243","#ffd13e","#45c27e","#42c4f5","#ff4342","#aedb7c","#9666ba","#fd9677","#0ec599","#10adf4","#faae1c","#0ec599"],
    
  });
  $("#populationPanel #lineChartBtn").click(function() {
    change('line');
  });
  function change(newType) {
    var ctx = document.getElementById("trainingChart").getContext("2d");
    // Remove the old chart and all its event handles
    if (myChart) {
      myChart.destroy();
    }
    // Chart.js modifies the object you pass in. Pass a copy of the object so we can use the original object later
    var temp = jQuery.extend(true, {}, config);
    temp.type = newType;
     //temp.type = newType;
    myChart = new Chart(ctx, temp);
  };
});
        $(document).ready(function(){
            var config = {
              type: 'line',
              data: {
                 labels: ["Kotputli", "Viratnagar", "Shahpura ", "Phulera", "Jhotwara", "Amer", "Ramgarh", "Bansur", "Baran", "Barmer", "Bikaner", "Churu"],
                datasets: [{
                  label: "Population",
                   data: [10, 13, 17, 12, 30, 47, 60, 120, 230, 300, 310, 400],
                 
                  fill: true,
                  borderColor: "rgba(49,172,170,0.9)",
                   backgroundColor:[ "#36a2eb","#ff6384","#ff9f40","#ffcd56","#4bc0c0","#aedb7c","#9666ba","#fd9677","#0ec599","#10adf4","#faae1c","#0ec599"],
             fill: false,
                pointRadius: 4,
               pointHitRadius: 10,
                },]
              },
              
              options: {
                responsive: true,
              legend: {
                 display: false,
                       // position: 'bottom',
                    },
                
                scales: {
               yAxes: [{
                 ticks: {
                  beginAtZero: false
                 },
                scaleLabel: {
                      labelString: 'Attendees',
                      display: true,
                    },
                }]
              },
              title: {
                fontSize: 12,
                display: true,
                text: 'Webinars Categories',
                position: 'bottom'
              }
              },
              
            };
      var myChart;
      change('line');
      $("#schoolCollagePanel #barChartBtn").click(function() {
        change('bar');
      });
      $("#schoolCollagePanel #pieChartBtn").click(function() {
        change('polarArea');
        //backgroundColor:[ "#ff4243","#ffd13e","#45c27e","#42c4f5","#ff4342","#aedb7c","#9666ba","#fd9677","#0ec599","#10adf4","#faae1c","#0ec599"],
        
      });
      $("#schoolCollagePanel #lineChartBtn").click(function() {
        change('line');
      });
      function change(newType) {
        var ctx = document.getElementById("webinarsChart").getContext("2d");
        // Remove the old chart and all its event handles
        if (myChart) {
          myChart.destroy();
        }
        // Chart.js modifies the object you pass in. Pass a copy of the object so we can use the original object later
        var temp = jQuery.extend(true, {}, config);
        temp.type = newType;
         //temp.type = newType;
        myChart = new Chart(ctx, temp);
      };
    });
      //Constituency Details
      $(document).ready(function(){
        var config = {
          type: 'bar',
          data: {
            labels: @json($years ),
            datasets: [{
              label: "Population",
               data: @json($earning ),
             
              fill: true,
              borderColor: "rgba(49,172,170,0.9)",
               backgroundColor:[ "#36a2eb","#ff6384","#ff9f40","#ffcd56","#4bc0c0","#aedb7c","#9666ba","#fd9677","#0ec599","#10adf4","#faae1c","#0ec599"],
         fill: false,
            pointRadius: 4,
           pointHitRadius: 10,
            },]
          },
          
          options: {
            responsive: true,
          legend: {
             display: false,
                   // position: 'bottom',
                },
            
              scales: {
            yAxes: [{
              ticks: {
               beginAtZero: false
              },
             scaleLabel: {
                  labelString: 'INR',
                  display: true,
                },
            }]
          },
          title: {
            fontSize: 12,
            display: true,
            text: 'Month',
            position: 'bottom'
          }
          },
          
        };
        var myChart;
        change('bar');
        $("#constituencyPanel #barChartBtn").click(function() {
          change('bar');
        });
        $("#constituencyPanel #pieChartBtn").click(function() {
          change('polarArea');
          //backgroundColor:[ "#ff4243","#ffd13e","#45c27e","#42c4f5","#ff4342","#aedb7c","#9666ba","#fd9677","#0ec599","#10adf4","#faae1c","#0ec599"],
          
        });
        $("#constituencyPanel #lineChartBtn").click(function() {
          change('line');
        });
        function change(newType) {
          var ctx = document.getElementById("constituencyDetailsChart").getContext("2d");
          // Remove the old chart and all its event handles
          if (myChart) {
            myChart.destroy();
          }
          // Chart.js modifies the object you pass in. Pass a copy of the object so we can use the original object later
          var temp = jQuery.extend(true, {}, config);
          temp.type = newType;
           //temp.type = newType;
          myChart = new Chart(ctx, temp);
        };
      });
        </script>
		<?php 
		}?>
        </html>
