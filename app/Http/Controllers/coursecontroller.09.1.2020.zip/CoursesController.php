<?php

namespace App\Http\Controllers;

use App\Models\Blog;
use App\Models\Bundle;
use App\Models\Category;
use App\Models\Course;
use App\Models\Review;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Stripe\Stripe;
use Stripe\Charge;
use Stripe\Customer;
use Cart;
use Auth; 
use App\Models\Departments;
use App\Models\Ministry;
use DB;
use App\Models\SettingManage;


class CoursesController extends Controller
{

    private $path;

    public function __construct()
    {
        $path = 'frontend';
        if(session()->has('display_type')){
            if(session('display_type') == 'rtl'){
                $path = 'frontend-rtl';
            }else{
                $path = 'frontend';
            }
        }else if(config('app.display_type') == 'rtl'){
            $path = 'frontend-rtl';
        }
        $this->path = $path;
    }

    public function all()
    { 
        $department_id = '0';
        if(Auth::check())
        {
            $id = Auth::user()->id;
              $user_details = DB::table('user_details')
                ->select('user_details.department_id')
                ->where('user_details.user_id', $id)
                ->latest('created_at')
                ->first();

            if($user_details){
                $department_id = $user_details->department_id;          
            }
        }

        if($department_id == 0){
            $department_id = session('department_id');
        }
        if(isset($department_id))
        {
            $departmentdata  = Departments::where('id',$department_id)->where('status',1)->first();
            $ministry_id = $departmentdata->ministry_id;
            $department_id = $departmentdata->id;
            $logo = $departmentdata->logo;
            $ministry = Ministry::where('id',$ministry_id)->where('status',1)->first();
            $allministry = Ministry::where('status',1)->get(); 
             $departments = Departments::where('id',$department_id)->where('status',1)->first();
             $alldepartments = Departments::where('ministry_id',$ministry_id)->where('status',1)->get();  
        }
        else
        {
            $setting = SettingManage::latest()->first();
            $ministry_id = $setting->ministry_id;
            $department_id = $setting->department_id;
            $logo = $setting->logo;
            $ministry = Ministry::where('id',$ministry_id)->where('status',1)->first();
            $allministry = Ministry::where('status',1)->get();
            //$request->session()->put('department_id', $department_id);
            session(['department_id' => $department_id]);
             $departments = Departments::where('id',$department_id)->where('status',1)->first();
             $alldepartments = Departments::where('ministry_id',$ministry_id)->where('status',1)->get();
        }

        if (request('type') == 'popular') {
            $courses = Course::withoutGlobalScope('filter')
           ->join('course_department', 'courses.id', '=', 'course_department.course_id')
           ->where('course_department.department_id',$department_id)
            ->where('published', 1)->where('popular', '=', 1) 
            ->orderBy('courses.id', 'desc')->paginate(9);

        } else if (request('type') == 'trending') {
            $courses = Course::withoutGlobalScope('filter')
            ->join('course_department', 'courses.id', '=', 'course_department.course_id')
           ->where('course_department.department_id',$department_id)
           ->where('published', 1)->where('trending', '=', 1)->orderBy('courses.id', 'desc')->paginate(9);

        } else if (request('type') == 'featured') {
            $courses = Course::withoutGlobalScope('filter')
            ->join('course_department', 'courses.id', '=', 'course_department.course_id')
           ->where('course_department.department_id',$department_id)
           ->where('published', 1)->where('featured', '=', 1)->orderBy('courses.id', 'desc')->paginate(9);

        } else {


            $courses = Course::withoutGlobalScope('filter')
            ->join('course_department', 'courses.id', '=', 'course_department.course_id')
           ->where('course_department.department_id',$department_id)->where('published', 1)->orderBy('courses.id', 'desc')->paginate(9);
        }
        $purchased_courses = NULL;
        $purchased_bundles = NULL;
        //$categories = Category::
         //join('department_categories', 'categories.id', '=', 'department_categories.cat_id')
           //->where('department_categories.department_id',$department_id)
      //->get();
		$categories = Category::where('status','=',1)->get();
        if (\Auth::check()) {
            $purchased_courses = Course::withoutGlobalScope('filter')->whereHas('students', function ($query) {
                $query->where('id', \Auth::id());
            })
                ->with('lessons')
                ->orderBy('id', 'desc')
                ->get();
        }
        $featured_courses = Course::withoutGlobalScope('filter')
        ->join('course_department', 'courses.id', '=', 'course_department.course_id')
           ->where('course_department.department_id',$department_id)->where('published', '=', 1)
            ->where('featured', '=', 1)->take(8)->get();

        $recent_news = Blog::orderBy('created_at', 'desc')->take(2)->get();
        return view( $this->path.'.courses.index', compact('courses', 'purchased_courses', 'recent_news','featured_courses','categories','ministry','departments','allministry','alldepartments','logo'));
    }

    public function show($course_slug)
    { 
  $department_id = '0';
        if(Auth::check())
        {
            $id = Auth::user()->id;
              $user_details = DB::table('user_details')
                ->select('user_details.department_id')
                ->where('user_details.user_id', $id)
                ->latest('created_at')
                ->first();

            if($user_details){
                $department_id = $user_details->department_id;          
            }
        }

        if($department_id == 0){
            $department_id = session('department_id');
        }
        if(isset($department_id))
        {
            $departmentdata  = Departments::where('id',$department_id)->where('status',1)->first();
            $ministry_id = $departmentdata->ministry_id;
            $department_id = $departmentdata->id;
            $logo = $departmentdata->logo;
            $ministry = Ministry::where('id',$ministry_id)->where('status',1)->first();
            $allministry = Ministry::where('status',1)->get(); 
             $departments = Departments::where('id',$department_id)->where('status',1)->first();
             $alldepartments = Departments::where('ministry_id',$ministry_id)->where('status',1)->get();  
        }
        else
        {
            $setting = SettingManage::latest()->first();
            $ministry_id = $setting->ministry_id;
            $department_id = $setting->department_id;
            $logo = $setting->logo;
            $ministry = Ministry::where('id',$ministry_id)->where('status',1)->first();
            $allministry = Ministry::where('status',1)->get();
            $request->session()->put('department_id', $department_id);
             $departments = Departments::where('id',$department_id)->where('status',1)->first();
             $alldepartments = Departments::where('ministry_id',$ministry_id)->where('status',1)->get();
        }


        $continue_course=NULL;
        $recent_news = Blog::orderBy('created_at', 'desc')->take(2)->get();
        $course = Course::withoutGlobalScope('filter')
        // ->join('course_department', 'courses.id', '=', 'course_department.course_id')
        //    ->where('course_department.department_id',$department_id)
        ->where('slug', $course_slug)->with('publishedLessons')->first();
		 $subcourseid =  $course->sub_cat_id;
         $subcourse = DB::table('courses')
                     ->join('categories','courses.category_id','=','categories.id')
                     ->join('sub_categories','courses.sub_cat_id','=','sub_categories.id')
                     ->select('courses.id','courses.title','courses.description','courses.course_image','categories.name','sub_categories.name as subname')
                     ->where('courses.sub_cat_id', $subcourseid)
                     ->get();
          
          
         $purchased_course = \Auth::check() && $course->students()->where('user_id', \Auth::id())->count() > 0;
        if(($course->published == 0) && ($purchased_course == false)){
            abort(404);
        }
        $course_rating = 0;
        $total_ratings = 0;
        $completed_lessons = "";
        $is_reviewed = false;
        if(auth()->check() && $course->reviews()->where('user_id','=',auth()->user()->id)->first()){
            $is_reviewed = true;
        }
        if ($course->reviews->count() > 0) {
            $course_rating = $course->reviews->avg('rating');
            $total_ratings = $course->reviews()->where('rating', '!=', "")->get()->count();
        }
        $lessons = $course->courseTimeline()->orderby('sequence','asc')->get();

        if (\Auth::check()) {

            $completed_lessons = \Auth::user()->chapters()->where('course_id', $course->id)->get()->pluck('model_id')->toArray();
            $continue_course  = $course->courseTimeline()->orderby('sequence','asc')->whereNotIn('model_id',$completed_lessons)->first();
            if($continue_course == null){
                $continue_course = $course->courseTimeline()->orderby('sequence','asc')->first();
            }

        }

        return view( $this->path.'.courses.course', compact('course', 'purchased_course', 'recent_news', 'course_rating', 'completed_lessons','total_ratings','is_reviewed','lessons','continue_course','ministry','departments','allministry','alldepartments','logo','subcourse'));
    }


    public function rating($course_id, Request $request)
    {
        $course = Course::
     join('course_department', 'courses.id', '=', 'course_department.course_id')
           ->where('course_department.department_id',$department_id)->findOrFail($course_id);
        $course->students()->updateExistingPivot(\Auth::id(), ['rating' => $request->get('rating')]);

        return redirect()->back()->with('success', 'Thank you for rating.');
    }

    public function getByCategory(Request $request)
    {
        $department_id = '0';
        if(Auth::check())
        {
            $id = Auth::user()->id;
              $user_details = DB::table('user_details')
                ->select('user_details.department_id')
                ->where('user_details.user_id', $id)
                ->latest('created_at')
                ->first();

            if($user_details){
                $department_id = $user_details->department_id;          
            }
        }

        if($department_id == 0){
            $department_id = session('department_id');
        }
        if(isset($department_id))
        {
            $departmentdata  = Departments::where('id',$department_id)->where('status',1)->first();
            $ministry_id = $departmentdata->ministry_id;
            $department_id = $departmentdata->id;
            $logo = $departmentdata->logo;
            $ministry = Ministry::where('id',$ministry_id)->where('status',1)->first();
            $allministry = Ministry::where('status',1)->get(); 
             $departments = Departments::where('id',$department_id)->where('status',1)->first();
             $alldepartments = Departments::where('ministry_id',$ministry_id)->where('status',1)->get();  
        }
        else
        {
            $setting = SettingManage::latest()->first();
            $ministry_id = $setting->ministry_id;
            $department_id = $setting->department_id;
            $logo = $setting->logo;
            $ministry = Ministry::where('id',$ministry_id)->where('status',1)->first();
            $allministry = Ministry::where('status',1)->get();
            $request->session()->put('department_id', $department_id);
             $departments = Departments::where('id',$department_id)->where('status',1)->first();
             $alldepartments = Departments::where('ministry_id',$ministry_id)->where('status',1)->get();
        }

        $category = Category::where('slug', '=', $request->category)
            ->where('status','=',1)
            ->first();
        $categories = Category::where('status','=',1)->get();

        if ($category != "") {
            $recent_news = Blog::orderBy('created_at', 'desc')->take(2)->get();
            $featured_courses = Course::where('published', '=', 1)
                ->where('featured', '=', 1)->take(8)->get();

            if (request('type') == 'popular') {
                $courses = $category->courses()->withoutGlobalScope('filter')
                ->join('course_department', 'courses.id', '=', 'course_department.course_id')
           ->where('course_department.department_id',$department_id)->where('published', 1)->where('popular', '=', 1)->orderBy('courses.id', 'desc')->paginate(9);

            } else if (request('type') == 'trending') {
                $courses = $category->courses()->withoutGlobalScope('filter')
                ->join('course_department', 'courses.id', '=', 'course_department.course_id')
           ->where('course_department.department_id',$department_id)->where('published', 1)->where('trending', '=', 1)->orderBy('courses.id', 'desc')->paginate(9);

            } else if (request('type') == 'featured') {
                $courses = $category->courses()->withoutGlobalScope('filter')
                ->join('course_department', 'courses.id', '=', 'course_department.course_id')
           ->where('course_department.department_id',$department_id)->where('published', 1)->where('featured', '=', 1)->orderBy('courses.id', 'desc')->paginate(9);

            } else {
                $courses = $category->courses()->withoutGlobalScope('filter')
                ->join('course_department', 'courses.id', '=', 'course_department.course_id')
           ->where('course_department.department_id',$department_id)->where('published', 1)->orderBy('courses.id', 'desc')->paginate(9);
            }


            return view( $this->path.'.courses.index', compact('courses', 'category', 'recent_news','featured_courses','categories','ministry','departments','allministry','alldepartments','logo'));
        }
        return abort(404);
    }

    public function addReview(Request $request)
    {
        $department_id = '0';
        if(Auth::check())
        {
            $id = Auth::user()->id;
              $user_details = DB::table('user_details')
                ->select('user_details.department_id')
                ->where('user_details.user_id', $id)
                ->latest('created_at')
                ->first();

            if($user_details){
                $department_id = $user_details->department_id;          
            }
        }

        if($department_id == 0){
            $department_id = session('department_id');
        }
        if(isset($department_id))
        {
            $departmentdata  = Departments::where('id',$department_id)->where('status',1)->first();
            $ministry_id = $departmentdata->ministry_id;
            $department_id = $departmentdata->id;
            $logo = $departmentdata->logo;
            $ministry = Ministry::where('id',$ministry_id)->where('status',1)->first();
            $allministry = Ministry::where('status',1)->get(); 
             $departments = Departments::where('id',$department_id)->where('status',1)->first();
             $alldepartments = Departments::where('ministry_id',$ministry_id)->where('status',1)->get();  
        }
        else
        {
            $setting = SettingManage::latest()->first();
            $ministry_id = $setting->ministry_id;
            $department_id = $setting->department_id;
            $logo = $setting->logo;
            $ministry = Ministry::where('id',$ministry_id)->where('status',1)->first();
            $allministry = Ministry::where('status',1)->get();
            $request->session()->put('department_id', $department_id);
             $departments = Departments::where('id',$department_id)->where('status',1)->first();
             $alldepartments = Departments::where('ministry_id',$ministry_id)->where('status',1)->get();
        }
        $this->validate($request, [
            'review' => 'required'
        ]);
        $course = Course::findORFail($request->id);
        $review = new Review();
        $review->user_id = auth()->user()->id;
        $review->reviewable_id = $course->id;
        $review->reviewable_type = Course::class;
        $review->rating = $request->rating;
        $review->content = $request->review;
        $review->save();

        return back();
    }

    public function editReview(Request $request)
    {
        $department_id = '0';
        if(Auth::check())
        {
            $id = Auth::user()->id;
              $user_details = DB::table('user_details')
                ->select('user_details.department_id')
                ->where('user_details.user_id', $id)
                ->latest('created_at')
                ->first();

            if($user_details){
                $department_id = $user_details->department_id;          
            }
        }

        if($department_id == 0){
            $department_id = session('department_id');
        }
        if(isset($department_id))
        {
            $departmentdata  = Departments::where('id',$department_id)->where('status',1)->first();
            $ministry_id = $departmentdata->ministry_id;
            $department_id = $departmentdata->id;
            $logo = $departmentdata->logo;
            $ministry = Ministry::where('id',$ministry_id)->where('status',1)->first();
            $allministry = Ministry::where('status',1)->get(); 
             $departments = Departments::where('id',$department_id)->where('status',1)->first();
             $alldepartments = Departments::where('ministry_id',$ministry_id)->where('status',1)->get();  
        }
        else
        {
            $setting = SettingManage::latest()->first();
            $ministry_id = $setting->ministry_id;
            $department_id = $setting->department_id;
            $logo = $setting->logo;
            $ministry = Ministry::where('id',$ministry_id)->where('status',1)->first();
            $allministry = Ministry::where('status',1)->get();
            $request->session()->put('department_id', $department_id);
             $departments = Departments::where('id',$department_id)->where('status',1)->first();
             $alldepartments = Departments::where('ministry_id',$ministry_id)->where('status',1)->get();
        }
        $review = Review::where('id', '=', $request->id)->where('user_id', '=', auth()->user()->id)->first();
        if ($review) {
            $course = $review->reviewable;
            $recent_news = Blog::orderBy('created_at', 'desc')->take(2)->get();
            $purchased_course = \Auth::check() && $course->students()->where('user_id', \Auth::id())->count() > 0;
            $course_rating = 0;
            $total_ratings = 0;
            $lessons = $course->courseTimeline()->orderby('sequence','asc')->get();

            if ($course->reviews->count() > 0) {
                $course_rating = $course->reviews->avg('rating');
                $total_ratings = $course->reviews()->where('rating', '!=', "")->get()->count();
            }
            if (\Auth::check()) {

                $completed_lessons = \Auth::user()->chapters()->where('course_id', $course->id)->get()->pluck('model_id')->toArray();
                $continue_course  = $course->courseTimeline()->orderby('sequence','asc')->whereNotIn('model_id',$completed_lessons)->first();
                if($continue_course == ""){
                    $continue_course = $course->courseTimeline()->orderby('sequence','asc')->first();
                }

            }
            return view( $this->path.'.courses.course', compact('course', 'purchased_course', 'recent_news','completed_lessons','continue_course', 'course_rating', 'total_ratings','lessons', 'review' ,'ministry','departments','allministry','alldepartments','logo'));
        }
        return abort(404);

    }


    public function updateReview(Request $request)
    {
        $review = Review::where('id', '=', $request->id)->where('user_id', '=', auth()->user()->id)->first();
        if ($review) {
            $review->rating = $request->rating;
            $review->content = $request->review;
            $review->save();

            return redirect()->route('courses.show', ['slug' => $review->reviewable->slug]);
        }
        return abort(404);

    }

    public function deleteReview(Request $request)
    {
        $review = Review::where('id', '=', $request->id)->where('user_id', '=', auth()->user()->id)->first();
        if ($review) {
            $slug = $review->reviewable->slug;
            $review->delete();
            return redirect()->route('courses.show', ['slug' => $slug]);
        }
        return abort(404);
    }
}
